
#ifndef REGIME_FACTORY_HPP
#define REGIME_FACTORY_HPP

#include "core/types.hpp"
#include <string>
#include <memory>

namespace ocas {

enum class OrbitalRegimeType {
    LEO, MEO, GEO, INVALID
};

enum class ManeuverPlane {
    AlongTrack, Radial, CrossTrack
};

enum class Urgency {
    Immediate, Priority, Routine
};

struct ManualAdvisory {
    int threat_id;
    OrbitalRegimeType regime;
    ManeuverPlane plane;

    double orbital_period_s;
    double burn_time_s;
    double lead_time_s;

    double target_separation_m;
    double required_displacement_m;
    double delta_v_mps;
    double predicted_separation_m;

    bool within_dv_cap;
    Urgency urgency;
};

class OrbitalRegime {
protected:
    double altitude_km;

public:
    OrbitalRegime(double altitude) {
        altitude_km = altitude;
    }

    virtual ~OrbitalRegime() {}

    virtual double calculate_risk(const Threat& t) const = 0;

    virtual ManualAdvisory calculate_advisory(const Threat& t) const = 0;

    virtual OrbitalRegimeType get_type() const = 0;
};


class LEORegime : public OrbitalRegime {
public:
    LEORegime(double altitude) : OrbitalRegime(altitude) {}

    double calculate_risk(const Threat& t) const override;

    ManualAdvisory calculate_advisory(const Threat& t) const override;

    OrbitalRegimeType get_type() const override {
        return OrbitalRegimeType::LEO;
    }
};


class MEORegime : public OrbitalRegime {
public:
    MEORegime(double altitude) : OrbitalRegime(altitude) {}

    double calculate_risk(const Threat& t) const override;

    ManualAdvisory calculate_advisory(const Threat& t) const override;

    OrbitalRegimeType get_type() const override {
        return OrbitalRegimeType::MEO;
    }
};


class GEORegime : public OrbitalRegime {
public:
    GEORegime(double altitude) : OrbitalRegime(altitude) {}

    double calculate_risk(const Threat& t) const override;

    ManualAdvisory calculate_advisory(const Threat& t) const override;

    OrbitalRegimeType get_type() const override {
        return OrbitalRegimeType::GEO;
    }
};


class RegimeFactory {
public:
    static OrbitalRegimeType classify(double altitude_km);

    static string get_regime_name(OrbitalRegimeType regime);

    static unique_ptr<OrbitalRegime> create_regime(double altitude_km);
};

}
#endif