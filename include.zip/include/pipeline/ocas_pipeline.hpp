
#ifndef OCAS_PIPELINE_HPP
#define OCAS_PIPELINE_HPP

#include <string>
#include <vector>
#include "core/types.hpp"

using namespace std;
using namespace ocas;

vector<Result> run_pipeline(string filename);

#endif
