
#ifndef CDM_IO_HPP
#define CDM_IO_HPP

#include <string>
#include <vector>
#include "core/types.hpp"

using namespace std;
using namespace ocas;

bool read_threats(string filename, vector<Threat>& threats);

#endif
