
#ifndef RISK_CLASSIFIER_HPP
#define RISK_CLASSIFIER_HPP

#include "core/types.hpp"

namespace ocas {

Result check_risk(Threat t);

}

#endif
