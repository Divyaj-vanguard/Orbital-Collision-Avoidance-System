
#ifndef TYPES_HPP
#define TYPES_HPP

using namespace std;

namespace ocas {

enum class Regime {
    LEO,
    MEO,
    GEO
};

enum class Risk {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
};


struct Threat {
    int id = 0;

    // Orbital conjunction features
    double distance = 0.0;  // Minimum separation distance in metres
    double speed = 0.0;     // Relative speed in km/s
    double time = 0.0;      // Time to closest approach in seconds
    double cov_trace = 0.0; // Covariance trace in m^2

    // Additional threat information
    double prob = 0.0;      // Collision probability
    double height = 0.0;    // Orbital height, if available
};


struct Result {
    int id = 0;

    // Numerical priority score used by the priority queue
    double score = 0.0;

    // Risk category mapped from the Random Forest prediction
    Risk risk = Risk::LOW;
    Regime regime = Regime::LEO;  // Add this

    // Confidence of the model's predicted category (0.0 to 1.0)
    double confidence = 0.0;

    bool maneuver = false;
};

}

#endif
