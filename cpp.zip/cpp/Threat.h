#ifndef THREAT_H
#define THREAT_H

#include <string>

struct Threat
{
    int alertID;
    float missDistance;
    float relativeVelocity;
    float timeToTCA;
    float covarianceTrace;

    std::string riskLevel;
    int priority;
};

#endif