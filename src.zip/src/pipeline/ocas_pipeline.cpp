
#include <iostream>
#include <queue>
#include <vector>

#include "data/cdm_io.hpp"
#include "risk/risk_classifier.hpp"

using namespace std;
using namespace ocas;

struct Compare {
    bool operator()(Result a, Result b) {
        return a.score < b.score;
    }
};

vector<Result> run_pipeline(string filename) {
    vector<Threat> threats;
    vector<Result> results;

    if (!read_threats(filename, threats)) {
        return results;
    }

    priority_queue<Result, vector<Result>, Compare> pq;

    for (Threat t : threats) {
        Result r = check_risk(t);
        pq.push(r);
    }

    while (!pq.empty()) {
        results.push_back(pq.top());
        pq.pop();
    }

    return results;
}
