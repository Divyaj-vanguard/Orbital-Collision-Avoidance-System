
#include <pybind11/embed.h>
#include <iostream>
#include <string>

using namespace std;
namespace py = pybind11;

int main() {
    try {
        cout << "Step 1: Starting Python..." << endl;
        py::scoped_interpreter guard{};

        cout << "Step 2: Python started." << endl;
        py::module_ sys = py::module_::import("sys");
        sys.attr("path").attr("insert")(0, ".");

        cout << "Step 3: Importing ml.predict..." << endl;
        py::module_ predict = py::module_::import("ml.predict");

        cout << "Step 4: Calling model..." << endl;
        py::object predict_risk = predict.attr("predict_risk");

        string risk = predict_risk(100.0, 8.1, 300.0, 800.0)
                          .cast<string>();

        cout << "Predicted risk: " << risk << endl;
    }
    catch (const py::error_already_set& e) {
        cerr << "Python error: " << e.what() << endl;
        return 1;
    }
    catch (const exception& e) {
        cerr << "C++ error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
