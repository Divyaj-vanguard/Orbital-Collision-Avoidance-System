
#include <iostream>
#include <string>

#include <pybind11/embed.h>

#include "core/types.hpp"

using namespace std;
namespace py = pybind11;

namespace ocas {

Regime get_regime(double height) {
    if (height < 2000)
        return Regime::LEO;
    else if (height < 35786)
        return Regime::MEO;
    else
        return Regime::GEO;
}

Result check_risk(Threat t) {
    Result r;

    r.id = t.id;
    r.regime = get_regime(t.height);

    try {
        // Start Python if it has not already been initialized.
        // In the pipeline, initialization should be managed by main().
        py::module_ predict = py::module_::import("ml.predict");

        py::object output = predict.attr("predict_risk")(
            t.distance,
            t.speed,
            t.time,
            t.cov_trace
        );

        // Receive the predicted class and confidence.
        py::tuple prediction = output.cast<py::tuple>();
        string label = prediction[0].cast<string>();
        r.confidence = prediction[1].cast<double>();

        // Map the model's labels to the existing C++ Risk enum.
        if (label == "Critical") {
            r.risk = Risk::CRITICAL;
            r.score = 100;
            r.maneuver = true;
        }
        else if (label == "High") {
            r.risk = Risk::HIGH;
            r.score = 75;
            r.maneuver = true;
        }
        else if (label == "Caution") {
            r.risk = Risk::MEDIUM;
            r.score = 50;
            r.maneuver = false;
        }
        else {
            r.risk = Risk::LOW;
            r.score = 25;
            r.maneuver = false;
        }
    }
    catch (const py::error_already_set& e) {
        cerr << "Python prediction error: " << e.what() << endl;
        r.risk = Risk::LOW;
        r.score = 0;
        r.confidence = 0;
        r.maneuver = false;
    }

    return r;
}

}
