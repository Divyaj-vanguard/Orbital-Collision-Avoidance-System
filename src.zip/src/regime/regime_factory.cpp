
#include "regime/regime_factory.hpp"

#include <algorithm>
#include <cmath>

namespace ocas {

namespace {
    const double PI = 3.141592653589793;
    const double MU = 398600.4418;
    const double EARTH_RADIUS = 6378.137;

    const double HOUR = 3600.0;
    const double DAY = 86400.0;

    double orbital_period(double altitude) {
        double radius = EARTH_RADIUS + altitude;
        double n = std::sqrt(MU / (radius * radius * radius));
        return 2.0 * PI / n;
    }

    ManualAdvisory make_advisory(
        const Threat& t,
        double altitude,
        OrbitalRegimeType regime,
        ManeuverPlane plane,
        double min_sep,
        double margin,
        double lead_orbits,
        double immediate,
        double priority,
        double routine,
        double dv_cap
    ) {
        ManualAdvisory a{};

        a.threat_id = t.id;
        a.regime = regime;
        a.plane = plane;
        a.orbital_period_s = orbital_period(altitude);

        double tca = std::max(0.0, t.time);
        double preferred = lead_orbits * a.orbital_period_s;

        if (tca >= margin + preferred) {
            a.burn_time_s = tca - preferred;
            a.lead_time_s = preferred;
        } else if (tca > margin) {
            a.burn_time_s = margin;
            a.lead_time_s = tca - margin;
        } else {
            a.burn_time_s = 0.0;
            a.lead_time_s = tca;
        }

        double d = std::max(0.0, t.distance);
        double sigma = 0.0;

        if (std::isfinite(t.cov_trace) && t.cov_trace > 0.0)
            sigma = std::sqrt(t.cov_trace / 3.0);

        a.target_separation_m = std::max({
            min_sep, 2.0 * sigma, 1.5 * d
        });

        a.required_displacement_m = std::sqrt(
            a.target_separation_m * a.target_separation_m - d * d
        );

        double n = 2.0 * PI / a.orbital_period_s;
        double x = n * a.lead_time_s;
        double gain;

        if (regime == OrbitalRegimeType::LEO) {
            gain = std::fabs(4.0 * std::sin(x) / n
                             - 3.0 * a.lead_time_s);
        } else if (regime == OrbitalRegimeType::MEO) {
            double s = std::sin(x);
            double c = std::cos(x);

            gain = std::sqrt(
                s * s + 4.0 * (1.0 - c) * (1.0 - c)
            ) / n;
        } else {
            gain = std::fabs(std::sin(x)) / n;
        }

        gain = std::max(gain, 1.0);

        a.delta_v_mps = a.required_displacement_m / gain;

        a.predicted_separation_m = std::sqrt(
            d * d + std::pow(a.delta_v_mps * gain, 2)
        );

        a.within_dv_cap = a.delta_v_mps <= dv_cap;

        if (tca <= immediate || tca <= margin)
           a.urgency = Urgency::Immediate;
        else if (tca <= priority)
           a.urgency = Urgency::Priority;
        else if (tca <= routine)
           a.urgency = Urgency::Routine;
        else
           a.urgency = Urgency::Routine;

        return a;
    }

    double proximity(double distance, double screen) {
        return std::exp(-std::max(0.0, distance) / screen);
    }

    double time_pressure(double tca, double window) {
        return std::exp(-std::max(0.0, tca) / window);
    }
}

// ---------------- LEO ----------------

double LEORegime::calculate_risk(const Threat& t) const {
    double severity = 0.75 + 0.25 *
        std::min(std::max(0.0, t.speed) / 15.0, 1.0);

    return proximity(t.distance, 1000.0) *
        (0.5 + 0.5 * time_pressure(t.time, 3.0 * DAY)) *
        severity;
}

ManualAdvisory LEORegime::calculate_advisory(const Threat& t) const {
    return make_advisory(t, altitude_km, get_type(),
        ManeuverPlane::AlongTrack, 1000.0, 1000.0,
        0.5 * HOUR, 8.0, 6.0 * HOUR, 3.0 * DAY, 1.0);
}

// ---------------- MEO ----------------

double MEORegime::calculate_risk(const Threat& t) const {
    return proximity(t.distance, 3000.0) *
        (0.5 + 0.5 * time_pressure(t.time, 4.0 * DAY));
}

ManualAdvisory MEORegime::calculate_advisory(const Threat& t) const {
    return make_advisory(t, altitude_km, get_type(),
        ManeuverPlane::Radial, 3000.0, 3000.0,
        1.0 * HOUR, 0.5, 12.0 * HOUR, 4.0 * DAY, 0.5);
}

// ---------------- GEO ----------------

double GEORegime::calculate_risk(const Threat& t) const {
    double dwell = 0.75 + 0.25 *
        std::exp(-std::max(0.0, t.speed));

    return proximity(t.distance, 5000.0) *
        (0.5 + 0.5 * time_pressure(t.time, 7.0 * DAY)) *
        dwell;
}

ManualAdvisory GEORegime::calculate_advisory(const Threat& t) const {
    return make_advisory(t, altitude_km, get_type(),
        ManeuverPlane::CrossTrack, 5000.0, 5000.0,
        2.0 * HOUR, 0.25, 1.0 * DAY, 7.0 * DAY, 0.5);
}

// ---------------- Factory ----------------

OrbitalRegimeType RegimeFactory::classify(double altitude) {
    if (!std::isfinite(altitude) || altitude < 100.0)
        return OrbitalRegimeType::INVALID;

    if (altitude < 2000.0)
        return OrbitalRegimeType::LEO;

    if (altitude < 35586.0)
        return OrbitalRegimeType::MEO;

    return OrbitalRegimeType::GEO;
}

std::string RegimeFactory::get_regime_name(
    OrbitalRegimeType regime) {

    switch (regime) {
        case OrbitalRegimeType::LEO: return "LEO";
        case OrbitalRegimeType::MEO: return "MEO";
        case OrbitalRegimeType::GEO: return "GEO";
        default: return "INVALID";
    }
}

std::unique_ptr<OrbitalRegime> RegimeFactory::create_regime(
    double altitude) {

    switch (classify(altitude)) {
        case OrbitalRegimeType::LEO:
            return std::make_unique<LEORegime>(altitude);

        case OrbitalRegimeType::MEO:
            return std::make_unique<MEORegime>(altitude);

        case OrbitalRegimeType::GEO:
            return std::make_unique<GEORegime>(altitude);

        default:
            return nullptr;
    }
}

}
