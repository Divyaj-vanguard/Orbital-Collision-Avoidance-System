
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#include "core/types.hpp"

using namespace std;
using namespace ocas;

// Remember how many physical data rows have been consumed.
static int rowsRead = 0;

bool read_threats(string filename, vector<Threat>& threats) {
    ifstream file(filename);
    string line;

    if (!file.is_open()) {
        cout << "File not found: " << filename << endl;
        return false;
    }

    // Skip the header.
    getline(file, line);

    // Skip all previously consumed data rows.
    for (int i = 0; i < rowsRead; i++) {
        if (!getline(file, line)) {
            cout << "No more records in the CSV file." << endl;
            return true;
        }
    }

    int validRecords = 0;
    int rowsConsumed = 0;

    // Read at most five valid records.
    while (validRecords < 5 && getline(file, line)) {
        rowsConsumed++;

        if (line.empty())
            continue;

        stringstream ss(line);
        string value;
        Threat t;

        try {
            if (!getline(ss, value, ',') || value.empty()) continue;
              t.id = stoi(value);

            if (!getline(ss, value, ',') || value.empty()) continue;
             t.distance = stod(value);

            if (!getline(ss, value, ',') || value.empty()) continue;
             t.speed = stod(value);

            if (!getline(ss, value, ',') || value.empty()) continue;
             t.time = stod(value);

            if (!getline(ss, value, ',') || value.empty()) continue;
             t.cov_trace = stod(value);

            if (!getline(ss, value, ',') || value.empty()) continue;
             t.prob = stod(value);
            
        }
        catch (const exception&) {
            cout << "Skipping invalid CSV row." << endl;
            continue;
        }

        if (t.id < 0 ||
            t.distance < 0 ||
            t.speed < 0 ||
            t.time < 0 ||
            t.cov_trace < 0 ||
            t.prob < 0 ||
            t.prob > 1) {
            cout << "Skipping invalid threat: " << t.id << endl;
            continue;
        }

        threats.push_back(t);
        validRecords++;
    }

    // Track physical rows, not just valid records.
    rowsRead += rowsConsumed;

    file.close();

    cout << "New threats loaded: " << validRecords << endl;
    return true;
}

