
#include <iostream>
#include <string>
#include <vector>
#include <mutex>
#include <queue>
#include <cstdlib>
#include <cmath>
#include <memory>
#include <fstream>

#include <pybind11/embed.h>

#include "core/types.hpp"
#include "data/cdm_io.hpp"
#include "risk/risk_classifier.hpp"
#include "regime/regime_factory.hpp"

using namespace std;
using namespace ocas;
namespace py = pybind11;

// Static singly linked list for final advisories
#define MAX_ADVISORIES 100

// OCAS Cyber Theme
#define RESET "\033[0m\033[38;5;46m"

#define RED     "\033[1;91m"
#define GREEN   "\033[1;92m"
#define YELLOW  "\033[1;93m"
#define BLUE    "\033[1;94m"
#define CYAN    "\033[1;96m"
#define MAGENTA "\033[1;95m"

#define BOLD    "\033[1m"
#define WHITE   "\033[1;97m"
#define PURPLE  "\033[38;5;135m"

struct Node {
    ManualAdvisory data;
    int next;
};

Node advisoryList[MAX_ADVISORIES];

int head = -1;
int freeIndex = 0;


void save_advisory_to_file(ManualAdvisory a) {

    ofstream file("advisory_log.txt", ios::app);

    if (!file.is_open()) {
        cout << "\nUnable to open advisory log file.\n";
        return;
    }

    file << "Threat ID: " << a.threat_id << endl;
    file << "Regime: "
         << RegimeFactory::get_regime_name(a.regime) << endl;

    file << "Delta V: " << a.delta_v_mps << " m/s" << endl;
    file << "Target Separation: "
         << a.target_separation_m << " m" << endl;

    file << "Predicted Separation: "
         << a.predicted_separation_m << " m" << endl;

    file << "Lead Time: " << a.lead_time_s << " seconds" << endl;
    file << "Burn Time: " << a.burn_time_s << " seconds" << endl;

    file << "-----------------------------" << endl;

    file.close();
}


// Compare threats by priority score
struct Compare {
    bool operator()(const Result& a, const Result& b) const {
        return a.score < b.score;
    }
};

void insert_advisory(ManualAdvisory a) {

    if (freeIndex >= MAX_ADVISORIES) {
        cout << "\nAdvisory list is full.\n";
        return;
    }

    int newIndex = freeIndex++;

    advisoryList[newIndex].data = a;
    advisoryList[newIndex].next = -1;

    if (head == -1) {
        head = newIndex;
    }
    else {
        int temp = head;

        while (advisoryList[temp].next != -1) {
            temp = advisoryList[temp].next;
        }

        advisoryList[temp].next = newIndex;
    }
}

void display_advisories() {

    cout << CYAN << BOLD
     << "\n========== MANEUVER HISTORY ==========\n"
     << RESET;

    
    if (head == -1) {
        cout << "\nNo advisories available.\n";
        return;
    }

    int temp = head;

    while (temp != -1) {

        cout << "\nThreat ID: "
             << advisoryList[temp].data.threat_id;

        cout << "\nDelta V: "
             << advisoryList[temp].data.delta_v_mps << " m/s";

        cout << "\nTarget Separation: "
             << advisoryList[temp].data.target_separation_m << " m";

        cout << "\nUrgency: ";

            if (advisoryList[temp].data.urgency == Urgency::Immediate)
              cout << RED << "Immediate" << RESET;

            else if (advisoryList[temp].data.urgency == Urgency::Priority)
              cout << YELLOW << "Priority" << RESET;

            else
              cout << GREEN << "Routine" << RESET;

        cout << "\n-------------------------\n";

        temp = advisoryList[temp].next;
    }
}
// Display pending threats
void view_pending(queue<Threat> q) {
    if (q.empty()) {
        cout << "\nNo pending threats in queue.\n";
        return;
    }

    cout << CYAN << BOLD << "\n===== PENDING THREATS =====\n" << RESET;

    int position = 1;

    while (!q.empty()) {
        Threat t = q.front();

        cout << "\nQueue Position: " << position++;
        cout << "\nThreat ID: " << t.id;
        cout << "\nDistance: " << t.distance << " m";
        cout << "\nRelative Speed: " << t.speed << " km/s";
        cout << "\nTime to TCA: " << t.time << " seconds";
        cout << "\nCovariance Trace: " << t.cov_trace << " m^2";
        cout << "\n----------------------------\n";

        q.pop();
    }
}

// Display processed threats
void view_results(
    priority_queue<Result, vector<Result>, Compare> q
) {
    if (q.empty()) {
        cout << "\nNo processed results available.\n";
        return;
    }

    cout << CYAN << BOLD << "\n===== PROCESSED THREATS =====\n" << RESET;

    while (!q.empty()) {
        Result r = q.top();
        q.pop();

        cout << "\nThreat ID: " << r.id;
        cout << "\nPriority Score: " << r.score;

        cout << "\nRisk Level: ";

        if (r.risk == Risk::CRITICAL)
          cout << RED << BOLD << "CRITICAL" << RESET;

        else if (r.risk == Risk::HIGH)
          cout << MAGENTA << "HIGH" << RESET;

        else if (r.risk == Risk::MEDIUM)
          cout << YELLOW << "CAUTION" << RESET;

        else
          cout << GREEN << "NOMINAL" << RESET;

        cout << "\nModel Confidence: "
             << r.confidence * 100 << "%";

        cout << "\nManeuver Recommended: "
             << (r.maneuver ? "YES" : "NO");

        cout << "\n----------------------------\n";
    }
}

// Generate an altitude-specific maneuver advisory
void generate_advisory(
    priority_queue<Result, vector<Result>, Compare> q,
    Threat records[],
    int count
) {
    if (q.empty()) {
        cout << "\nNo processed threats available.\n";
        return;
    }

    // Select the highest-priority threat
    Result r = q.top();

    cout << "\n===== HIGHEST-PRIORITY THREAT =====\n";
    cout << "Threat ID: " << r.id;
    cout << "\nPriority Score: " << r.score;
    cout << "\nManeuver Recommended: "
         << (r.maneuver ? "YES" : "NO") << "\n";

    // Find the original CDM record
    Threat t{};
    bool found = false;

    for (int i = 0; i < count; i++) {
        if (records[i].id == r.id) {
            t = records[i];
            found = true;
            break;
        }
    }

    if (!found) {
        cout << "Original threat data not found.\n";
        return;
    }

    cout << "\n===== THREAT DETAILS =====\n";
    cout << "Miss Distance: " << t.distance << " m\n";
    cout << "Relative Speed: " << t.speed << " km/s\n";
    cout << "Time to TCA: " << t.time << " seconds\n";
    cout << "Covariance Trace: " << t.cov_trace << " m^2\n";

    // Do not calculate a maneuver if ML says it is unnecessary
    if (!r.maneuver) {
        cout << "\nThe ML model does not recommend a maneuver.\n";
        cout << "No maneuver advisory generated.\n";
        return;
    }

    // Get the host spacecraft's altitude from the user
    double altitude;

    cout << "\nEnter host spacecraft altitude (km): ";

    if (!(cin >> altitude) ||
        !isfinite(altitude) ||
        altitude < 100.0) {
        cin.clear();
        cin.ignore(10000, '\n');
        cout << "Invalid altitude. Enter a valid altitude in km.\n";
        return;
    }

    // Factory chooses the appropriate orbital class
    unique_ptr<OrbitalRegime> regime =
        RegimeFactory::create_regime(altitude);

    if (!regime) {
        cout << "No suitable orbital regime could be created.\n";
        return;
    }

    // The selected orbital class calculates its own advisory
    ManualAdvisory a = regime->calculate_advisory(t);

    int y;
    cout<<"\nAdvisory to be Stored in Linked list?\n";
    cout<<"\n1. YES\n";
    cout<<"\n2. NO\n";
    cin>>y;
    if(y==1){

    insert_advisory(a);
    }

    save_advisory_to_file(a);

cout <<GREEN<< "\nAdvisory automatically saved to advisory_log.txt\n"<<RESET;

    cout << GREEN << BOLD << "\n========== MANEUVER ADVISORY ==========\n" << RESET;

    cout << "Threat ID: " << a.threat_id << "\n";
    cout << "Host Altitude: " << altitude << " km\n";

    cout << "Orbital Class: "
         << RegimeFactory::get_regime_name(a.regime) << "\n";

    cout << "Orbital Period: "
         << a.orbital_period_s << " seconds\n";

    cout << "\n--- Maneuver Plan ---\n";

    cout << "Maneuver Plane: ";

    if (a.plane == ManeuverPlane::AlongTrack)
        cout << "Along Track";
    else if (a.plane == ManeuverPlane::Radial)
        cout << "Radial";
    else
        cout << "Cross Track";

    cout << "\nUrgency: ";

    if (a.urgency == Urgency::Immediate)
        cout << "Immediate";
    else if (a.urgency == Urgency::Priority)
        cout << "Priority";
    else
        cout << "Routine";

    cout << "\nBurn Time: " << a.burn_time_s << " seconds";
    cout << "\nLead Time: " << a.lead_time_s << " seconds";

    cout << "\nTarget Separation: "
         << a.target_separation_m << " m";

    cout << "\nRequired Displacement: "
         << a.required_displacement_m << " m";

    cout << "\nRequired Delta-V: "
         << a.delta_v_mps << " m/s";

    cout << "\nPredicted Separation: "
         << a.predicted_separation_m << " m";

    cout << "\nWithin Regime Delta-V Cap: "
         << (a.within_dv_cap ? "YES" : "NO");

    cout << "\n\n=======================================\n";
    cout << "Simulation advisory only; not a flight command.\n";
}



void display_menu() {

    cout << "\033[38;5;46m";
    cout << "\n";
    cout << "  ==================================================\n";
    cout << "       ____   ____    _    ____  \n";
    cout << "      / __ \\ / ___|  / \\  / ___| \n";
    cout << "     | |  | | |     / _ \\ \\___ \\ \n";
    cout << "     | |__| | |___ / ___ \\ ___) |\n";
    cout << "      \\____/ \\____/_/   \\_\\____/ \n";
    cout << "  ==================================================\n";
    cout << RESET;

    cout << CYAN << BOLD;
    cout << "            ORBITAL COLLISION AVOIDANCE SYSTEM\n";
    cout << RESET;

    cout << BLUE;
    cout << "\n  --------------------------------------------------\n";
    cout << "                     MAIN MENU\n";
    cout << "  --------------------------------------------------\n";
    cout << RESET;

    cout << YELLOW << "   [1] " << RESET << "Load Threat Data\n";
    cout << YELLOW << "   [2] " << RESET << "View Pending Threats\n";
    cout << YELLOW << "   [3] " << RESET << "Run Risk Assessment\n";
    cout << YELLOW << "   [4] " << RESET << "View Prioritized Threats\n";
    cout << YELLOW<< "   [5] " << RESET << "Generate Maneuver Advisory\n";
    cout << YELLOW<< "   [6] " << RESET << "View Maneuver History\n";
    cout << RED << "   [7] " << RESET << "Exit System\n";

    cout << BLUE;
    cout << "\n  --------------------------------------------------\n";
    cout << RESET;

    cout << YELLOW << BOLD << "   ENTER YOUR CHOICE >> " << RESET;
}




int main() {
    cout << CYAN;
    try {
        // Configure Python before initialization
        _putenv_s(
            "PYTHONHOME",
            "C:\\Users\\HP\\AppData\\Local\\Programs\\Python\\Python313"
        );

        _putenv_s(
            "PYTHONPATH",
            "C:\\Users\\HP\\AppData\\Local\\Programs\\Python\\Python313\\Lib\\site-packages"
        );

        // Start embedded Python
        py::scoped_interpreter guard{};

        py::module_ sys = py::module_::import("sys");

        sys.attr("path").attr("insert")(0, ".");

        sys.attr("path").attr("insert")(
            0,
            "C:/Users/HP/AppData/Local/Programs/Python/Python313/Lib/site-packages"
        );

        // Main queues
        queue<Threat> inputQueue;

        priority_queue<Result, vector<Result>, Compare> priorityQueue;

        // Store original threats without using a map
        const int MAX_RECORDS = 100;
        Threat records[MAX_RECORDS];
        int recordCount = 0;

        const int CAPACITY = 5;
        int choice = 0;

        do {
          display_menu();

          if (!(cin >> choice)) {
          cin.clear();
          cin.ignore(10000, '\n');

          cout << RED << "\nInvalid input! Enter a number.\n" << RESET;
          continue;
        }

            switch (choice) {
                case 1: {
                    if (inputQueue.size() >= CAPACITY) {
                        cout << "\nQueue is full. Process pending threats first.\n";
                        break;
                    }

                    if (recordCount >= MAX_RECORDS) {
                        cout << "\nThreat record storage is full.\n";
                        break;
                    }

                    vector<Threat> batch;

                    int slots = CAPACITY -
                        static_cast<int>(inputQueue.size());

                    if (!read_threats(
                            "data/cleaned_cdm_dataset.csv", batch)) {
                        cout << RED << "\nCould not read the CDM file.\n" << RESET;
                        break;
                    }

                    int transferred = 0;

                    for (const Threat& t : batch) {
                        if (transferred >= slots)
                            break;

                        if (recordCount >= MAX_RECORDS) {
                            cout << "Threat record storage is full.\n";
                            break;
                        }

                        inputQueue.push(t);
                        records[recordCount] = t;
                        recordCount++;

                        transferred++;
                    }

                    cout << GREEN << "\nRecords transferred to queue: "
                         << transferred << RESET << "\n";

                    if (batch.empty()) {
                        cout << "No new records were loaded.\n";
                    }

                    if (transferred < static_cast<int>(batch.size())) {
                        cout << "Some records were not transferred.\n";
                        cout << "Check the CSV reader to retain remaining records.\n";
                    }

                    break;
                }

                case 2:
                    view_pending(inputQueue);
                    break;

                case 3: {
                    if (inputQueue.empty()) {
                        cout << "\nNo pending threats. Transfer data first.\n";
                        break;
                    }

                    cout << "\nSending threats to Random Forest...\n";

                    while (!inputQueue.empty()) {
                        Threat t = inputQueue.front();
                        inputQueue.pop();

                        Result r = check_risk(t);
                        priorityQueue.push(r);

                        cout << "Processed Threat ID: "
                             << t.id << "\n";
                    }

                    cout << GREEN << BOLD
                         << "\nML processing completed successfully.\n"
                         << RESET;

                    break;
                }

                case 4:
                    view_results(priorityQueue);
                    break;

                case 5:
                    generate_advisory(
                        priorityQueue,
                        records,
                        recordCount
                    );
                    break;

                case 6:
                    display_advisories();
                    break;
                case 7:
                    cout << GREEN << BOLD<< "\nOCAS shutdown completed. Goodbye!\n"<< RESET;
                    break;
                default:
                    cout << RED << "\nInvalid choice. Choose 1 to 7.\n" << RESET;
            }

        } while (choice != 7);
    }
    catch (const py::error_already_set& e) {
        cerr << "\nPython error:\n" << e.what() << endl;
        return 1;
    }
    catch (const exception& e) {
        cerr << "\nOCAS error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
